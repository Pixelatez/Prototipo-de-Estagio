using NUnit.Framework;
using Range = UnityEngine.RangeAttribute;
using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEditor;

public class PersonagemJogavel : MonoBehaviour, IDamageable
{
    public float VidaAtual { get { return vidaAtual; } }
    public float VidaMaxima { get { return vidaMaxima; } }

    [Header("Variaveis de Vida")]

    [SerializeField]
    protected float vidaAtual = 100f;
    [SerializeField]
    protected float vidaMaxima = 100f;

    [Header("Variaveis de Movimento Horizontal")]

    [SerializeField]
    private float velocidade = 8f;

    [Header("Variaveis de Movimento Vertical")]

    [SerializeField]
    private float gravidade = 3f;
    [SerializeField]
    private float tamanhoPulo = 15f;
    [SerializeField, Tooltip("O qu�o longe do ch�o o jogador pode ficar e ainda contar como 'est� no ch�o' para coisas como pulo, gravidade, etc."), Range(0.5f, 0.01f)]
    private float distanciaChao = 0.15f;
    [SerializeField, Tooltip("Quais LayerMasks contam como ch�o.")]
    private LayerMask maskChao;

    [Header("Outros")]

    [SerializeField]
    protected bool modoDebug = false;

    protected InputJogador input;
    private Collider2D colisor;
    private Rigidbody2D rb;
    private bool noChao;
    private bool emPulo = false;
    private bool coyoteTime = false;
    private bool inventarioAberto = false;

    #region Start e Input

    protected virtual void Awake()
    {
        input = new InputJogador();
        colisor = GetComponent<Collider2D>();
        rb = GetComponent<Rigidbody2D>();
    }

    protected virtual void OnEnable()
    {
        input.Enable();
        input.Movimento.Andar.Enable();
        input.Movimento.Pular.Enable();
        input.Outros.Inventario.Enable();
        input.Movimento.Pular.performed += PuloInput;
        input.Outros.Inventario.performed += InventarioInput;
    }

    protected virtual void OnDisable()
    {
        input.Disable();
        input.Movimento.Andar.Disable();
        input.Movimento.Pular.Disable();
        input.Outros.Inventario.Disable();
        input.Movimento.Pular.performed -= PuloInput;
        input.Outros.Inventario.performed -= InventarioInput;
    }

    #endregion

    protected virtual void FixedUpdate()
    {
        // Raycasts dependem da f�sica do Unity, que s� � processada a cada FixedUpdate.
        noChao = ChecagemChao();

        // Mudar a gravidade do RigidBody2D para a configurada no script.
        rb.gravityScale = gravidade;

        // Pegar input do jogador.
        Vector2 inputMovimento = input.Movimento.Andar.ReadValue<Vector2>();

        if (inputMovimento.magnitude == 0) // Se n�o tiver input do jogador, o jogador para de se mover.
        {
            rb.linearVelocityX = 0;
        }
        else
        {
            rb.linearVelocityX = inputMovimento.x * velocidade;
        }
    }

    #region Pulo

    private void PuloInput(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if ((noChao || coyoteTime) && !emPulo) // Se o jogador estiver no ch�o ou em Coyote Time e j� n�o estiver em pulo.
            {
                Vector2 forcaPulo = new(0f, tamanhoPulo);
                coyoteTime = false;
                StartCoroutine(Pulo()); // Espera o jogador sair do ch�o ou uma quantidade de tempo passar para poder pular novamente, evitando multiplos pulos em um.
                rb.AddForce(forcaPulo, ForceMode2D.Impulse);
            }
        }
    }

    private IEnumerator Pulo()
    {
        emPulo = true;
        float tempo = 0.15f;
        while (noChao || coyoteTime) // Esperar at� 0.15 segundos passarem ou o jogador n�o estiver no ch�o e n�o estiver em Coyote Time.
        {
            yield return null;
            tempo -= Time.deltaTime;
            if (tempo <= 0f) break;
        }
        emPulo = false;
    }

    #endregion

    private void InventarioInput(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if (inventarioAberto)
            {

            }
            else
            {

            }
        }
    }

    private bool ChecagemChao()
    {
        // Achar a parte mais inferior do jogador (o "p�" dele)
        Vector2 parteInferior = new(transform.position.x, colisor.bounds.min.y - distanciaChao / 2);
        Vector2 tamanho = new(Mathf.Abs(colisor.bounds.min.x - colisor.bounds.max.x), distanciaChao);

        // Criar Raycast para verificar se tiver ch�o
        RaycastHit2D hit = Physics2D.BoxCast(parteInferior, tamanho, 0, Vector3.down, distanciaChao / 2, maskChao);

        if (hit.collider == null) // Se n�o tiver ch�o:
        {
            return false;
        }
        else // Se tiver:
        {
            return true;
        }
    }

    public void LevarDano(float dano)
    {
        vidaAtual = Mathf.Clamp(vidaAtual - dano, 0, vidaMaxima);
    }

    protected virtual void OnDrawGizmos()
    {
        if (modoDebug)
        {
            colisor = GetComponent<Collider2D>();
            Vector3 parteInferior = new(transform.position.x, colisor.bounds.min.y - distanciaChao / 2);
            Vector3 tamanho = new(Mathf.Abs(colisor.bounds.min.x - colisor.bounds.max.x), distanciaChao);

            Vector3[] quadradoVertices = new Vector3[4];

            for (int i = 0; i < 4; i++)
            {
                int l = -1;
                int a = -1;

                if (i >= 2) { a = 1; }
                if (i % 3 == 0) { l = 1; }

                quadradoVertices[i] = parteInferior + new Vector3((tamanho.x / 2) * l, (tamanho.y / 2) * a);
            }

            Handles.DrawSolidRectangleWithOutline(quadradoVertices, new Color(0, 1, 0, 0.3f), Color.green);
        }
    }
}
