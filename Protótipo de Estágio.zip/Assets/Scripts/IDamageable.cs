using UnityEngine;

public interface IDamageable
{
    public void LevarDano(float dano);
}
